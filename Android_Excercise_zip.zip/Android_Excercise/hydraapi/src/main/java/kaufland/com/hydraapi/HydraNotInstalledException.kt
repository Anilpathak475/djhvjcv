package kaufland.com.hydraapi

class HydraNotInstalledException : Exception() {
}