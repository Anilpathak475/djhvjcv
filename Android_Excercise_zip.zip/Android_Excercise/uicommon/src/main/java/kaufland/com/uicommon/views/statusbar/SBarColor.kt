package kaufland.com.uicommon.views.statusbar

import androidx.annotation.ColorInt

interface SBarColor {
    @ColorInt
    fun getStatusBarColor(): Int
}