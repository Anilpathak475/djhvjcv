package kaufland.com.uicommon.views.keyboard

interface KeyboardActivity {

    fun keyboardView() : CalculatorKeyboard
}