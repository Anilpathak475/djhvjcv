package kaufland.com.uicommon.views.toolbar

interface TNavigationIcon {
}