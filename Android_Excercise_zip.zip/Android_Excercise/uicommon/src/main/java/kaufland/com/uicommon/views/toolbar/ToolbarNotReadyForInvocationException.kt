package kaufland.com.uicommon.views.toolbar

import java.lang.Exception

class ToolbarNotReadyForInvocationException : Exception() {

}
