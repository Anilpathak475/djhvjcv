package kaufland.com.uicommon.views.fragment;

import androidx.fragment.app.Fragment;

public interface KlFragment {

    Fragment getFragment();

    boolean isVisible();

    String getFragmentTag();

}
