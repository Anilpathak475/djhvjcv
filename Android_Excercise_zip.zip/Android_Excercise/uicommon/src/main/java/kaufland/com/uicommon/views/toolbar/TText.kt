package kaufland.com.uicommon.views.toolbar

import androidx.annotation.ColorInt

interface TText {

    fun getToolbarText(): String
}